 <!-- Brand Logo Start -->
 <div class="section techwix-brand-section" id="brand">
            <div class="container">
                <!-- Brand Wrapper Start -->
                <div class="brand-wrapper section-padding text-center">
                    <h3 class="brand-title">Cansan'ın <span>1.000</span> başarılı müşterisinden biri olmak için bir adım öne çıkın.</h3>

                    <!-- Brand Active Start -->
                    <div class="brand-active">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-1.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-2.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-3.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-4.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-5.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-6.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                                <!-- Single Brand Start -->
                                <div class="swiper-slide single-brand">
                                    <img src="assets/images/brand/brand-7.png" alt="Brand">
                                </div>
                                <!-- Single Brand End -->
                            </div>
                        </div>
                    </div>
                    <!-- Brand Active End -->
                </div>
                <!-- Brand Wrapper End -->
            </div>
        </div>
        <!-- Brand Logo End -->
        <!-- Footer Section Start -->
        <div class="section footer-section" style="background-image: url(assets/images/bg/footer-bg.jpg);">

            <div class="container">
                <!-- Footer Widget Wrap Start -->
                <div class="footer-widget-wrap">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget-about">
                                <a class="footer-logo" href="index.html"><img src="assets/images/logo-white.png" alt="Logo"></a>
                                <p>Birinci sınıf teknoloji ekipleriyle yeniliği hızlandırın Sizi inanılmaz serbest çalışan yeteneklerden oluşan uzaktan bir ekiple eşleştireceğiz.</p>
                                <div class="footer-social">
                                    <ul class="social">
                                        <li><a href="https://www.facebook.com/cansan_boya"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="https://twitter.com/cansan_boya"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="https://www.linkedin.com/cansan_boya"><i class="fab fa-linkedin-in"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Referanslarımız</h4>

                                <div class="widget-link">
                                    <ul class="link">
                                        <li><a href="https://kleidco.com">Kleidco</a></li>
                                        <li><a href="https://maryapi.com.tr">Mar Yapı</a></li>
                                        <li><a href="https://www.daikin.com.tr">Daikin</a></li>
                                        <li><a href="http://www.mottasarim.com">Mot Tasarım</a></li>
                                        <li><a href="http://www.efnotomotiv.com">EFN Otomativ</a></li>
                                        <li><a href="https://www.mercedes-benz.com.tr">Mercedes</a></li>
                                        <li><a href="https://senermekanik.com">Şener Mekanik</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Hizmetlerimiz</h4>

                                <div class="widget-link">
                                    <ul class="link">
                                        <li><a href="#">Toz Boya ve Yüzey İşlem</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Footer Widget Start -->
                            <div class="footer-widget">
                                <h4 class="footer-widget-title">Bizimle İletişime Geçin</h4>

                                <div class="widget-info">
                                    <ul>
                                        <li>
                                            <div class="info-icon">
                                                <i class="flaticon-phone-call"></i>
                                            </div>
                                            <div class="info-text">
                                                <span><a href="#">+90 (212) 485 82 72</a></span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-icon">
                                                <i class="far fa-envelope-open"></i>
                                            </div>
                                            <div class="info-text">
                                                <span><a href="#">iletisim@cansanboya.com.tr</a></span>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="info-icon">
                                                <i class="flaticon-pin"></i>
                                            </div>
                                            <div class="info-text">
                                                <span>Adres : İ.O.S.B Çevre San. Sit. 8. Blok No: 2-4-6 Başakşehir/İstanbul</span>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Footer Widget End -->
                        </div>
                    </div>
                </div>
                <!-- Footer Widget Wrap End -->
            </div>

            <!-- Footer Copyright Start -->
            <div class="footer-copyright-area">
                <div class="container">
                    <div class="footer-copyright-wrap">
                        <div class="row align-items-center">
                            <div class="col-lg-12">
                                <!-- Footer Copyright Text Start -->
                                <div class="copyright-text text-center">
                                    <p>2023 © <a href="http://karakuzu.info" target="_blank">karakuzu.info</a>  Tüm hakları saklıdır.</p>
                                </div>
                                <!-- Footer Copyright Text End -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Copyright End -->
        </div>
        <!-- Footer Section End -->

        <!-- back to top start -->
        <div class="progress-wrap">
            <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
                <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
            </svg>
        </div>
        <!-- back to top end -->

    </div>

    <!-- JS
    ============================================ -->
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="assets/js/plugins/popper.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <script src="assets/js/plugins/aos.js"></script>
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <script src="assets/js/plugins/back-to-top.js"></script>
    <script src="assets/js/plugins/jquery.counterup.min.js"></script>
    <script src="assets/js/plugins/appear.min.js"></script>
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->


    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
    
    <script>
        $(document).ready(function() {
     
            $('#mn<?php echo $ekranAdi; ?>Btn').attr('class', 'active-menu');
            
            $('#mn<?php echo $ekranAdi; ?>Btn').closest('ul').closest('li').attr('class', 'active-menu');

        });
    </script>
</body>

</html>