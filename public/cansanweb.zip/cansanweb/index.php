<?php 
include 'header.php';
$ekranAdi = "AnaSayfa";
?>

        <!-- Offcanvas Start-->
        <div class="offcanvas offcanvas-start" id="offcanvasExample">
            <div class="offcanvas-header">
                <!-- Offcanvas Logo Start -->
                <div class="offcanvas-logo">
                    <a href="index.html"><img src="assets/images/logo-white.png" alt=""></a>
                </div>
                <!-- Offcanvas Logo End -->
                <button type="button" class="close-btn" data-bs-dismiss="offcanvas"><i class="flaticon-close"></i></button>
            </div>

            <!-- Offcanvas Body Start -->
            <div class="offcanvas-body">
                <div class="offcanvas-menu">
                    <ul class="main-menu">
                        <li class="active-menu">
                            <a href="index.html">Home</a>
                            <ul class="sub-menu">
                                <li><a href="index.html">Home Main</a></li>
                                <li><a href="index-2.html">AI Solutions</a></li>
                                <li><a href="index-3.html">Cyber Security</a></li>
                                <li><a href="index-4.html">IT Solutions</a></li>
                                <li class="active"><a href="index-5.html">Software Company</a></li>
                                <li><a href="index-6.html">IT Agency</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="about.html">Aboute Us</a>
                        </li>
                        <li><a href="#">Pages</a>
                            <ul class="sub-menu">
                                <li><a href="team.html">Our Team</a></li>
                                <li><a href="service.html">Service</a></li>
                                <li><a href="choose-us.html">Why Choose Us</a></li>
                                <li><a href="testimonial.html">Testimonial</a></li>
                                <li><a href="pricing.html">Pricing</a></li>
                                <li><a href="login-register.html">Login & Register</a></li>
                            </ul>
                        </li>
                        <li><a href="#">Blog</a>
                            <ul class="sub-menu">
                                <li><a href="blog.html">Blog Grid</a></li>
                                <li><a href="blog-standard.html">Blog List</a></li>
                                    <li><a href="blog-details.html">Blog Single</a></li>
                            </ul>
                        </li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
            </div>
            <!-- Offcanvas Body End -->
        </div>
        <!-- Offcanvas End -->
        
        ELEKTROSTATIK TOZ BOYACANSAN

        <!-- Hero Start -->
        <div class="section techwix-hero-section" style="background-image: url(assets/images/bg/hero-bg1.png);">
            <div class="shape-2"></div>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <!-- Hero Content Start -->
                        <div class="hero-content">
                            <h2 class="title" data-aos="fade-up" data-aos-delay="800">ELEKTROSTATIK TOZ</h2>
                            <div class="hero-btn" data-aos="fade-up" data-aos-delay="1000">
                                <a class="btn" href="about.html">Kalite Belgelerimiz</a>
                                <a class="btn" href="about.html">İletişim</a>
                            </div>
                        </div>
                        <!-- Hero Content End -->
                    </div>
                    <div class="col-lg-7">
                        <!-- Hero Image Start -->
                        <div class="hero-images">
                            <div class="images">
                                <img src="assets/images/anasayfa_kayan2" alt="">
                            </div>
                        </div>
                        <!-- Hero Image ennd -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero End -->

        <!-- Service Start -->
        <div class="section techwix-service-section section-padding-02" style="text-align: center;">
            <div class="container">
                <!-- Service Wrap Start -->
                <div class="service-wrap">
                    <div class="section-title text-center">
                        <h3 class="sub-title">Hizmetlerimiz</h3>
                        <h2 class="title">Slogan Yer Alıcak</h2>
                    </div>
                    <div class="service-content-wrap">
                        <div class="row">
                            <div class="col-xl-4 col-sm-6">
                                <!-- Service Item Start -->
                                <div class="service-item service-01">
                                    <div class="service-img">
                                        <img src="assets/images/ser-icon1.png" alt="">
                                    </div>
                                    <div class="service-content">
                                        <h3 class="title"><a href="service.html">Yüzey İşlem</a></h3>
                                        <p>Ürünleriniz, hammaddesinin gerektirdiği şekilde boya öncesi kimyasal işlemine alınır.
                                         Yüzey işlem çeşidini seçebilir veya konuyu profesyonel ekibimize bırakabilirsiniz.</p>
                                    </div>
                                </div>
                                <!-- Service Item End -->
                            </div>
                            <div class="col-xl-4 col-sm-6">
                                <!-- Service Item Start -->
                                <div class="service-item">
                                    <div class="service-img">
                                        <img src="assets/images/ser-icon2.png" alt="">
                                    </div>
                                    <div class="service-content">
                                        <h3 class="title"><a href="service.html">Boyama</a></h3>
                                        <p>Seçtiğiniz yüzey çeşidi ve parlaklıktaki rengi, ürününüzün kullanılacağı yere bağlı olarak
                                         önereceğimiz boya çeşidiyle boyayıp, dilediğiniz koşulların oluşmasını sağlıyoruz.</p>
                                    </div>
                                </div>
                                <!-- Service Item End -->
                            </div>
                            <div class="col-xl-4 col-sm-6">
                                <!-- Service Item Start -->
                                <div class="service-item service-03">
                                    <div class="service-img">
                                        <img src="assets/images/ser-icon3.png" alt="">
                                    </div>
                                    <div class="service-content">
                                        <h3 class="title"><a href="service.html">Paketleme</a></h3>
                                        <p>Ürün son hale geldikten sonra, depolama ve sevkiyat esnasında hasar görmemesi için
                                         gerekli<br> malzemelerle paketlenip, siz değerli müşterimize hazır hale getirilir. </p>
                                    </div>
                                </div>
                                <!-- Service Item End -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Service Wrap End -->
            </div>
        </div>
        <!-- Service End -->

        <!-- Cta Start -->
        <div class="section techwix-cta-section section-padding">
            <div class="container">
                <div class="cta-wrap">
                    <div class="cta-icon">
                        <img src="assets/images/cta-icon1.png" alt="">
                    </div>
                    <div class="cta-content text-center">
                        <p>En iyi hizmet için <a href="#">bizimle iletişime geçin.</a></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Cta End -->

        <!-- About Start -->
        <div class="section techwix-about-section section-padding" style="background-image: url(assets/images/bg/about-bg.png);">
            <div class="shape-1"></div>
            <div class="container">
                <!-- About Wrapper Start -->
                <div class="about-wrap">
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- About Image Wrap Start -->
                            <div class="about-img-wrap">
                                <div class="about-img about-img-big">
                                    <img src="assets/images/about-1.jpg" alt="">
                                </div>
                                <div class="about-img about-img-sm">
                                    <img src="assets/images/about-2.jpg" alt="">
                                    <div class="shape-01"></div>
                                </div>
                            </div>
                            <!-- About Image Wrap End -->
                        </div>
                        <div class="col-lg-6">
                            <!-- About Content Wrap Start -->
                            <div class="about-content-wrap">
                                <div class="section-title">
                                    <h3 class="sub-title">Biz Kimiz?</h3>
                                    <h2 class="title">CANSAN ENDÜSTRİ ve OTOMOTİV</h2>
                                </div>
                                <p>Otomotiv sektöründeki ürünleri desteklediğimiz markaların gücüyle birleştirerek, 
                                dürüstlük ve çalışma azmiyle yenilikçi ve kaliteli üretimler sunuyoruz. Rekabet 
                                gücümüzü her zaman en üst seviyede tutarak, çevre ve insana duyarlı bir yaklaşımla 
                                öncü bir şirket olarak güven veriyoruz.</p>
                                <div class="play-btn">
                                    <a class="popup-video" href="https://www.youtube.com/watch?time_continue=3&v=_X0eYtY8T_U"><i class="fas fa-play"></i> <span>How we work</span></a>
                                </div>
                            </div>
                            <!-- About Content Wrap End -->
                        </div>
                    </div>
                </div>
                <!-- About Wrapper End -->
            </div>
        </div>
        <!-- About End -->

        <!-- About Start -->
        <div class="section techwix-about-section-02 section-padding">
            <div class="container">
                <!-- About Wrapper Start -->
                <div class="about-wrap">
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- About Left Start -->
                            <div class="about-02-left text-center">
                                <div class="section-title">
                                    <h2 class="title">Tüm çabalarınız beklenmedik bir şekilde meyvesini vermeye başladığında
                                     doğru yaptığınızı biliyorsunuz ve tüm dijital hizmetleri etkin bir şekilde yönetebiliyoruz.</h2>
                                </div>
                                <div class="about-author">
                                    <h3 class="name">Alen Morno sin</h3>
                                    <span class="designation">CEO, Techmax</span>
                                </div>
                            </div>
                            <!-- About Left End -->
                        </div>
                        <div class="col-lg-6">
                            <!-- About Right Start -->
                            <div class="about-02-right">
                                <p>Birinci sınıf teknoloji ekipleriyle inovasyonu hızlandırın Tüm yazılım geliştirme 
                                ihtiyaçlarınız için sizi inanılmaz serbest yeteneklerden oluşan uzaktan bir ekiple 
                                eşleştireceğiz.</p>
                                <div class="about-list">
                                    <ul>
                                        <li>
                                            <span class="about-icon"><i class="fas fa-check"></i></span>
                                            <span class="about-text">Her zaman teknik mükemmelliğe odaklanıyoruz.</span>
                                        </li>
                                        <li>
                                            <span class="about-icon"><i class="fas fa-check"></i></span>
                                            <span class="about-text">Nereye giderseniz gidin, fikir ve heyecanı beraberinde getiriyoruz.</span>
                                        </li>
                                        <li>
                                            <span class="about-icon"><i class="fas fa-check"></i></span>
                                            <span class="about-text">Markaların danışmanları, rehberleri ve ortaklarıyız</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!-- About Right End -->
                        </div>
                    </div>
                </div>
                <!-- About Wrapper End -->
            </div>
        </div>
        <!-- About End -->

        <!-- Counter Start -->
        <div class="section techwix-counter-section">
            <div class="container">
                <div class="counter-wrap">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6">
                            <!-- Single Counter Start -->
                            <div class="single-counter">
                                <div class="counter-img">
                                    <img src="assets/images/counter-1.png" alt="">
                                </div>
                                <div class="counter-content">
                                    <span class="counter">1790</span>
                                    <p>MUTLU MÜŞTERİLER</p>
                                </div>
                            </div>
                            <!-- Single Counter End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Single Counter Start -->
                            <div class="single-counter">
                                <div class="counter-img">
                                    <img src="assets/images/counter-2.png" alt="">
                                </div>
                                <div class="counter-content">
                                    <span class="counter">491</span>
                                    <p>BİTMİŞ PROJELER</p>
                                </div>
                            </div>
                            <!-- Single Counter End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Single Counter Start -->
                            <div class="single-counter">
                                <div class="counter-img">
                                    <img src="assets/images/counter-3.png" alt="">
                                </div>
                                <div class="counter-content">
                                    <span class="counter">245</span>
                                    <p>Nitelikli Uzmanlar</p>
                                </div>
                            </div>
                            <!-- Single Counter End -->
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <!-- Single Counter Start -->
                            <div class="single-counter">
                                <div class="counter-img">
                                    <img src="assets/images/counter-1.png" alt="">
                                </div>
                                <div class="counter-content">
                                    <span class="counter">1090</span>
                                    <p>Medya Gönderileri</p>
                                </div>
                            </div>
                            <!-- Single Counter End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Counter End -->

        <!-- Case Study Start -->
        <div class="section techwix-case-study-section section-padding-02">
            <div class="container">
                <div class="case-study-wrap">
                    <div class="section-title text-center">
                        <h3 class="sub-title">Case studies</h3>
                        <h2 class="title">Hizmet Verdiğimiz Sektörler</h2>
                    </div>
                    <div class="case-study-content-wrap">
                        <div class="swiper-container case-study-active">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <!-- Single Case Study Start -->
                                    <div class="single-case-study">
                                        <div class="case-study-img">
                                            <a href="#"><img src="assets/images/case-1.jpg" alt=""></a>
                                        </div>
                                        <div class="case-study-content">
                                            <h3 class="title"><a href="#">Otomotiv Yan Sanayi Sektörü</a></h3>
                                        </div>
                                    </div>
                                    <!-- Single Case Study End -->
                                </div>
                                <div class="swiper-slide">
                                    <!-- Single Case Study Start -->
                                    <div class="single-case-study">
                                        <div class="case-study-img">
                                            <a href="#"><img src="assets/images/case-2.jpg" alt=""></a>
                                        </div>
                                        <div class="case-study-content">
                                            <h3 class="title"><a href="#">İnşaat Sektörü</a></h3>
                                        </div>
                                    </div>
                                    <!-- Single Case Study End -->
                                </div>
                                <div class="swiper-slide">
                                    <!-- Single Case Study Start -->
                                    <div class="single-case-study">
                                        <div class="case-study-img">
                                            <a href="#"><img src="assets/images/case-3.jpg" alt=""></a>
                                        </div>
                                        <div class="case-study-content">
                                            <h3 class="title"><a href="#">Sağlık Sektörü</a></h3>
                                        </div>
                                    </div>
                                    <!-- Single Case Study End -->
                                </div>
                                <div class="swiper-slide">
                                    <!-- Single Case Study Start -->
                                    <div class="single-case-study">
                                        <div class="case-study-img">
                                            <a href="#"><img src="assets/images/case-4.jpg" alt=""></a>
                                        </div>
                                        <div class="case-study-content">
                                            <h3 class="title"><a href="#">Makina İmalat Sektörü</a></h3>
                                        </div>
                                    </div>
                                    <!-- Single Case Study End -->
                                </div>
                                <div class="swiper-slide">
                                    <!-- Single Case Study Start -->
                                    <div class="single-case-study">
                                        <div class="case-study-img">
                                            <a href="#"><img src="assets/images/case-5.jpg" alt=""></a>
                                        </div>
                                        <div class="case-study-content">
                                            <h3 class="title"><a href="#">Reklam ve Mağaza Sektörü</a></h3>
                                        </div>
                                    </div>
                                    <!-- Single Case Study End -->
                                </div>
                                <div class="swiper-slide">
                                    <!-- Single Case Study Start -->
                                    <div class="single-case-study">
                                        <div class="case-study-img">
                                            <a href="#"><img src="assets/images/case-6.jpg" alt=""></a>
                                        </div>
                                        <div class="case-study-content">
                                            <h3 class="title"><a href="#">Savunma Ana Sanayi Sektörü</a></h3>
                                        </div>
                                    </div>
                                    <!-- Single Case Study End -->
                                </div>
                            </div>

                            <!-- Add Pagination -->
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Case Study End -->

        <!-- Testimonial Start  -->
        <div class="section techwix-testimonial-section section-padding-02">
            <div class="container">
                <!-- Testimonial Wrap Start  -->
                <div class="testimonial-wrap">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="testimonial-img">
                                <div class="shape-1">
                                    <img src="assets/images/shape/testi-shape1.png" alt="">
                                </div>
                                <img src="assets/images/testi-img.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="testimonial-content-wrap">
                                <div class="swiper-container testimonial-active">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <!--  Single Testimonial Start  -->
                                            <div class="single-testimonial">
                                                <img src="assets/images/testi-icon.png" alt="">
                                                <p>Accelerate innovation with world-class tech teams Beyond more stoic this along goodness hey this this wow manatee </p>
                                                <span class="name">Mike Holder </span>
                                                <span class="designation"> / CEO, Harlond inc</span>
                                            </div>
                                            <!--  Single Testimonial End  -->
                                        </div>
                                        <div class="swiper-slide">
                                            <!--  Single Testimonial Start  -->
                                            <div class="single-testimonial">
                                                <img src="assets/images/testi-icon.png" alt="">
                                                <p>Accelerate innovation with world-class tech teams Beyond more stoic this along goodness hey this this wow manatee </p>
                                                <span class="name">Mike Holder </span>
                                                <span class="designation"> / CEO, Harlond inc</span>
                                            </div>
                                            <!--  Single Testimonial End  -->
                                        </div>
                                        <div class="swiper-slide">
                                            <!--  Single Testimonial Start  -->
                                            <div class="single-testimonial">
                                                <img src="assets/images/testi-icon.png" alt="">
                                                <p>Accelerate innovation with world-class tech teams Beyond more stoic this along goodness hey this this wow manatee </p>
                                                <span class="name">Mike Holder </span>
                                                <span class="designation"> / CEO, Harlond inc</span>
                                            </div>
                                            <!--  Single Testimonial End  -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Testimonial Wrap End  -->
            </div>
        </div>
        <!-- Testimonial End  -->

<?php include 'footer.php'; ?>