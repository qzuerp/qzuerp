<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Techwix - Technology IT Solutions Consultancy HTML5 Template</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
	============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/plugins/all.min.css">
    <link rel="stylesheet" href="assets/css/plugins/flaticon.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/aos.css">
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <!-- <link rel="stylesheet" href="assets/css/vendor/plugins.min.css">
    <link rel="stylesheet" href="assets/css/style.min.css"> -->

</head>

<body>

    <div class="main-wrapper">


        <!-- Preloader start -->
        <div id="preloader">
            <div class="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- Preloader End -->

        <!-- Header Start  -->
        <div id="header" class="section header-section">

            <div class="container">

                <!-- Header Wrap Start  -->
                <div class="header-wrap">

                    <div class="header-logo">
                        <a href="index"><img src="assets/images/logo.png" alt=""></a>
                    </div>

                    <div class="header-menu d-none d-lg-block">
                        <ul class="main-menu">
                            <li id="mnAnaSayfaBtn">
                                <a href="index.php">Ana Sayfa</a>
                            </li>
                            <li><a href="#">Kurumsal</a>
                                <ul class="sub-menu">
                                    <li id="mnTarihceBtn"><a href="tarihce.php">Tarihçe</a></li>
                                    <li id="mnHakkimizdaBtn"><a href="about.php">Hakkımızda</a></li>
                                    <li id="mnKaliteBelgelerimizBtn"><a href="about.php#kalite_belgelerimiz">Kalite Belgelerimiz</a></li>
                                    <li id="mnReferanslarimizBtn"><a href="index#brand">Referanslarımız</a></li>
                                </ul>
                            </li>
                            <li id="mnTesisimizBtn">
                                <a href="team.php">Tesisimiz</a> 
                            </li>
                            <li id="mnIletisimBtn">
                                <a href="contact.php">İletişim</a>
                            </li>
                        </ul>
                    </div>

                    <!-- Header Meta Start -->
                    <div class="header-meta">
                        <!-- Header Cart Start -->
                        <div class="header-cart dropdown">
                           
                            <!-- Header Dropdown Cart End -->
                        </div>
                        <!-- Header Cart End -->
                        <!-- Header Search Start -->
                        <div class="header-search">
                            
                        </div>
                        <!-- Header Search End -->

                        <div class="header-btn d-none d-xl-block">
                            <a class="btn" href="login-register">+90 (212) 485 82 72</a>
                            <center><a href="mailto:iletisim@cansanboya.com.tr" target="_blank"><small>iletisim@cansanboya.com.tr</small></a></center>
                        </div>
                        <!-- Header Toggle Start -->
                        <div class="header-toggle d-lg-none">
                            <button data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                        <!-- Header Toggle End -->
                    </div>
                    <!-- Header Meta End  -->

                </div>
                <!-- Header Wrap End  -->

            </div>
        </div>
        <!-- Header End -->